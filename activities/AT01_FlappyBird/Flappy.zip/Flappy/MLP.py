
class MLP(object):
	"""
	Uma rede neural(Perceptron-multilayer) de 3 camadas
	"""
	def __init__(self,entrada, oculta, saida, taxaDeAprendizado = 0.1):
		"""
		Entrada : número de entradas, de neurônios ocultos e saidas. Podendo também variar a taxa de aprendizado
		"""
		pass	
	
	def getTaxaDeAprendizado(self):
		pass	
		
	def setTaxaDeAprendizado(self,taxa):
		pass	

	def ativacaoSigmoidal(valor):
		"""
		Função ativadora Sigmoidal = 1 / (1 + e ^ - valor)
		Entrada : Valor a ser aplicado na função
		Retorno : Resultado da aplicação
		"""
		pass	

	def derivadaAtivacaoSigmoidal(valor):
		"""
		Derivada da função ativadora Sigmoidal , dSigmoidal / dValor = Sigmoidal *(1 - Sigmoidal)
		Entrada : Valor(Resultante da aplicação à sigmoidal) a ser aplicado na função
		Retorno : Resultado da aplicação
		"""
		pass	

	def erroQuadraticoMedio(esperado, valor):
		"""
		Calculo do erro
		Entrada : O target e o valor deduzido
		Retorno : Erro calculado dadas as entradas
		"""		
		pass	


	def feedForward(self, dados):
		"""
		Recebe as entradas e faz a classificação
		Entrada : As N entradas(float) definidas no __init__
		Retorno : Nenhum
		"""
		pass	


	def backPropagation(self, esperado):
		"""
		Pondera as classificações e faz as correções aos pesos
		Entrada : Targets(float)
		Retorno : Nenhum
		"""
		pass	

	
	def treinamento(self, dados, esperado):
		pass

